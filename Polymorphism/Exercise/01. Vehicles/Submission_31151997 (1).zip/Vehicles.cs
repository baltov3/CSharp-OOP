﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
  public abstract  class Vehicles
    {
        public double FuelQuantity { get; set; }
        public virtual double FuelConsumption { get; set; }

        protected Vehicles(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }
        public bool CanDrive (double km) => FuelQuantity -(km * FuelConsumption)>=0;



        public void Drive(double km)
        {
            if (CanDrive(km))
            {
                this.FuelQuantity -= km * FuelConsumption;
            }

        }
        public virtual void Refuel(double amount)
        {
            this.FuelQuantity += amount;

        }
    }
}

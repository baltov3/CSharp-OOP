﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Entities.Foods;

namespace WildFarm.Entities.Animals
{
    public abstract class Animal : IAnimal
    {
        protected Animal(string name, double weight)
        {
            Name = name;
            Weight = weight;
        }

        public  string Name { get; set; }
        public  double Weight { get; set; }
        public  int FoodEaten { get; set; }
        public string MyProperty { get; set; }

        public abstract string ProduceSound();
        public abstract void Eat(IFood food);

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Entities.Foods;

namespace WildFarm.Entities.Animals
{
    public abstract class Feline : Mammal
    {
        protected Feline(string name, double weight, string livingRegion, string breed) : base(name, weight, livingRegion)
        {
            this.Breed = breed;
        }

        public string Breed { get; set; }

        public override string ToString() => $"{this.GetType().Name} [{this.Name}, {Breed}, {this.Weight}, {this.LivingRegion}, {FoodEaten}]";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Entities.Foods;

namespace WildFarm.Entities.Animals
{
    class Hen : Bird
    {
        private const double Modifier = 0.35;
        public Hen(string name, double weight, double wingSize) : base(name, weight, wingSize)
        {
        }

        public override string ProduceSound() => "Cluck";

        public override void Eat(IFood food)
        {
            this.Weight += Modifier * food.Quantity;
            FoodEaten += food.Quantity;
        }
    }
}

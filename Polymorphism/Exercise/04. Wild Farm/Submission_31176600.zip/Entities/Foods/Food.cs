﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Entities.Foods
{
    public abstract class Food : IFood
    {
        protected Food(int quantity)
        {
           this. Quantity = quantity;
        }

        public int Quantity { get; }
    }
}

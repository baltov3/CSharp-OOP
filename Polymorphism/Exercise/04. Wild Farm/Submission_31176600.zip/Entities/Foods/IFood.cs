﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Entities.Foods
{
   public  interface IFood
    {
        public int Quantity { get; }
    }
}

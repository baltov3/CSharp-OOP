﻿using System;
using System.Collections.Generic;
using WildFarm.Entities.Animals;
using WildFarm.Entities.Foods;

namespace WildFarm
{
   public class Program
    {
        static void Main(string[] args)
        {
            List<IAnimal> animals = new List<IAnimal>();
            string input = Console.ReadLine();
            while (input!="End")
            {
                try
                {
                    string[] animalInfo = input.Split();
                    string[] foodInfo = Console.ReadLine().Split();
                    string type = animalInfo[0];
                    string name = animalInfo[1];
                    double weight = double.Parse(animalInfo[2]);
                    IAnimal animal = null;
                    if (type == "Cat" || type == "Tiger")
                    {
                        string livingRegion = animalInfo[3];
                        string breed = animalInfo[4];
                        if (type == "Cat")
                        {
                            animal = new Cat(name, weight, livingRegion, breed);
                        }
                        else
                        {
                            animal = new Tiger(name, weight, livingRegion, breed);
                        }
                    }
                    else if (type == "Owl" || type == "Hen")
                    {
                        double wingSize = double.Parse(animalInfo[3]);
                        if (type == "Owl")
                        {
                            animal = new Owl(name, weight, wingSize);
                        }
                        else
                        {
                            animal = new Hen(name, weight, wingSize);
                        }

                    }
                    else
                    {
                        string livingRegion = animalInfo[3];
                        if (type == "Dog")
                        {
                            animal = new Dog(name, weight, livingRegion);
                        }
                        else
                        {
                            animal = new Mouse(name, weight, livingRegion);
                        }
                    }
                    Console.WriteLine(animal.ProduceSound());
                    animals.Add(animal);
                    string foodType = foodInfo[0];
                    int qty = int.Parse(foodInfo[1]);
                    IFood food = null;
                    if (foodType == "Vegetable")
                    {
                        food = new Vegetable(qty);
                    }
                    else if (foodType == "Fruit")
                    {
                        food = new Fruit(qty);
                    }
                    else if (foodType == "Meat")
                    {
                        food = new Meat(qty);
                    }
                    else if (foodType == "Seads")
                    {
                        food = new Seeds(qty);
                    }
                    animal.Eat(food);
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                }

                input = Console.ReadLine();
            }
            foreach (var item in animals)
            {
                Console.WriteLine(item.ToString());
            }
        }
    }
}
